/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;
I2C_Handle i2c;

// Global variables for temperature and set-point
int16_t currentTemp = 20;
int16_t setPointTemp = 22;
int heatStatus = 0;
uint32_t secondsSinceReset = 0;

// UART Global Variables
char output[64];
UART_Handle uart;

// Function to initialize I2C
void initI2C(void) {
    int8_t i;
    bool found = false;
    I2C_Params i2cParams;

    snprintf(output, 64, "Initializing I2C Driver - ");
    UART_write(uart, output, strlen(output));

    // Initialize the I2C driver
    I2C_init();

    // Configure the I2C parameters
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;  // Set I2C speed to 400kHz

    // Open the I2C driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL) {
        snprintf(output, 64, "Failed\n\r");
        UART_write(uart, output, strlen(output));
        while (1);  // Infinite loop on failure
    }

    snprintf(output, 32, "Passed\n\r");
    UART_write(uart, output, strlen(output));

    // Set up a common I2C transaction
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;

    // Scan through possible sensor addresses
    for (i = 0; i < 3; ++i) {
        i2cTransaction.slaveAddress = sensors[i].address;  // Set sensor address
        txBuffer[0] = sensors[i].resultReg;  // Set the register to read from
        snprintf(output, 64, "Is this %s? ", sensors[i].id);
        UART_write(uart, output, strlen(output));

        // Perform I2C transfer
        if (I2C_transfer(i2c, &i2cTransaction)) {
            snprintf(output, 64, "Found\n\r");
            UART_write(uart, output, strlen(output));
            found = true;
            break;  // Exit loop once the sensor is found
        }

        snprintf(output, 64, "No\n\r");
        UART_write(uart, output, strlen(output));
    }

    // Handle sensor detection result
    if (found) {
        snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.slaveAddress);
        UART_write(uart, output, strlen(output));
    } else {
        snprintf(output, 64, "Temperature sensor not found, contact professor\n\r");
        UART_write(uart, output, strlen(output));
    }
}

// Function to read temperature from I2C sensor
int16_t readTemp(void) {
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;  // Set read count to 2 bytes

    // Perform I2C transfer to read temperature
    if (I2C_transfer(i2c, &i2cTransaction)) {
        // Extract degrees C from the received data
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;  // Conversion factor to degrees Celsius

        // Handle 2's complement negative values
        if (rxBuffer[0] & 0x80) {
            temperature |= 0xF000;  // Sign extend for negative temperature
        }
    } else {
        snprintf(output, 64, "Error reading temperature sensor (%d)\n\r", i2cTransaction.status);
        UART_write(uart, output, strlen(output));
    }

    return temperature;
}

// Function to initialize UART
void initUART(void) {
    UART_Params uartParams;

    // Init the driver
    UART_init();

    // Configure the driver
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    // Open the driver
    uart = UART_open(CONFIG_UART_0, &uartParams);
    if (uart == NULL) {
        // UART_open() failed
        while (1);
    }
}

// Function to send data to UART in the required format
void reportStatus(void) {
    snprintf(output, sizeof(output), "<%02d,%02d,%d,%04d>\r\n",
             currentTemp, setPointTemp, heatStatus, secondsSinceReset);
    UART_write(uart, output, strlen(output));
}

// Timer and Task Scheduling
Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;

void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
    TimerFlag = 1;
}

// Function to control LED and "heater"
void controlHeater(void) {
    if (currentTemp < setPointTemp) {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Turn on LED (heater on)
        heatStatus = 1;
    } else {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF); // Turn off LED (heater off)
        heatStatus = 0;
    }
}

// Function to initialize the timer
void initTimer(void) {
    Timer_Params timerParams;

    Timer_init();  // Initialize Timer driver

    Timer_Params_init(&timerParams);  // Configure default parameters
    timerParams.period = 200000;      // 200ms period
    timerParams.periodUnits = Timer_PERIOD_US;
    timerParams.timerMode = Timer_CONTINUOUS_CALLBACK;
    timerParams.timerCallback = timerCallback;

    // Open the timer
    timer0 = Timer_open(CONFIG_TIMER_0, &timerParams);
    if (timer0 == NULL) {
        while (1);  // Infinite loop on failure
    }

    // Start the timer
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        while (1);  // Infinite loop on failure
    }
}

// Function to check button input and adjust set-point
void checkButtons(void) {
    if (GPIO_read(CONFIG_GPIO_BUTTON_0) == 0) {
        setPointTemp += 1;  // Increase set-point
    }
    if (GPIO_read(CONFIG_GPIO_BUTTON_1) == 0) {
        setPointTemp -= 1;  // Decrease set-point
    }
}

// Main Thread with Task Scheduler
void *mainThread(void *arg0) {
    // Initialize peripherals
    GPIO_init();
    initUART();  // UART must be initialized before initI2C
    initI2C();
    initTimer();

    // Configure GPIO (LED and buttons)
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    // Turn off LED at start
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);

    // Main loop with task scheduling
    unsigned int buttonCheckCount = 0;
    unsigned int tempCheckCount = 0;
    unsigned int reportCount = 0;

    while (1) {
        if (TimerFlag) {
            TimerFlag = 0;
            buttonCheckCount += 200;
            tempCheckCount += 200;
            reportCount += 200;

            // Check buttons every 200ms
            if (buttonCheckCount >= 200) {
                checkButtons();
                buttonCheckCount = 0;
            }

            // Check temperature every 500ms
            if (tempCheckCount >= 500) {
                currentTemp = readTemp();
                controlHeater();
                tempCheckCount = 0;
            }

            // Report status every second
            if (reportCount >= 1000) {
                secondsSinceReset++;
                reportStatus();
                reportCount = 0;
            }
        }
    }
}
